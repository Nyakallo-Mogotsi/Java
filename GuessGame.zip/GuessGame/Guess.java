
import javafx.scene.control.TextField;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.geometry.*;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import javafx.scene.layout.StackPane;
import java.util.Random;
import javafx.scene.control.TextArea;
import javafx.scene.control.Alert;


/**
 * Write a description of JavaFX class Guess here.
 *
 * @author (Nyakallo Mogotsi StuNo.:41782240)
 * @version (16 May 2023)
 */
public class Guess extends Application
{
    Button randBtn = new Button("Random Number");
    Button checkm = new Button("Check Match");
    Button clear = new Button("Clear all components");
    Button quit = new Button("Quit Game");
    TextField tf = new TextField();
    TextArea ta = new TextArea();
    int count = 1;
    public static void main(String[] args) {
        launch(args);
        
    }
    
    @Override
    public void start(Stage primaryStage) throws Exception {
        primaryStage.setTitle("Guess Game");
        
        StackPane layout = new StackPane();
        Label label = new Label("Enter a number: ");
        Label label2 = new Label("Click 'Random Number' ");
        Scene scene = new Scene(layout, 600 , 550);
        layout.getChildren().addAll(randBtn, label , tf , checkm, ta, clear, label2 , quit);
        tf.requestFocus();
        
        StackPane.setAlignment(randBtn, Pos.TOP_LEFT);
        StackPane.setMargin(randBtn, new Insets(30));
        
        StackPane.setAlignment(label, Pos.TOP_LEFT);
        StackPane.setMargin(label, new Insets(70,200,200,30));
        
        StackPane.setAlignment(tf, Pos.TOP_LEFT);
        StackPane.setMargin(tf, new Insets(70,200,200,150));
        
        StackPane.setAlignment(checkm, Pos.TOP_LEFT);
        StackPane.setMargin(checkm, new Insets(100,200,200,30));
        
        StackPane.setAlignment(ta, Pos.TOP_LEFT);
        StackPane.setMargin(ta, new Insets(150,200,200,30));
        
        StackPane.setAlignment(clear, Pos.BOTTOM_LEFT);
        StackPane.setMargin(clear, new Insets(400,200,70,30));
        
        StackPane.setAlignment(label2, Pos.TOP_LEFT);
        StackPane.setMargin(label2, new Insets(40,200,200,150));
        
        StackPane.setAlignment(quit, Pos.BOTTOM_RIGHT);
        StackPane.setMargin(quit, new Insets(400,200,70,30));
        
        randBtn.setOnAction(event -> 
        {
            getRandNum();
        });
        
        checkm.setOnAction(event -> 
        {
            checkNum();
            count++;
            tf.setText("");
            tf.requestFocus();
        });
        
        clear.setOnAction(event -> 
        {
            clearAll();
        });
        
        quit.setOnAction(event -> 
        {
            quit();
        });
        
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    public int getRandNum()
    {
        Random random = new Random();
        int randomNum = 0;
        
        while(true)
        {
            randomNum = random.nextInt(11);
            if (randomNum!=0) 
                break;
        }
        
        return randomNum;
    }
    public int getText()
    {
        int num = Integer.parseInt(tf.getText());
        
        return num;
    }
    public void checkNum()
    {
        if (getRandNum() < getText())
        {
            ta.appendText("Your guess is " + getText() + " - too high\n");
        }
        else if (getRandNum() > getText())
        {
            ta.appendText("Your guess is " + getText() + " - too low\n");
        }
        else
        {
            ta.appendText("Your guess is " + getText() + " - Correct!\n");
            ta.appendText("Number of guesses: " + count);
        }
    }
    public void clearAll()
    {
        ta.setText("");
        tf.setText("");
        tf.requestFocus();
        count=1;
    }
    public void quit()
    {
    Alert alert = new Alert(Alert.AlertType.INFORMATION);
    alert.setTitle("Quit Game");
    alert.setHeaderText("Message");
    alert.setContentText("GoodBye");
    alert.showAndWait();
    System.exit(0);
    }


}
