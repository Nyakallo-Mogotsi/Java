
/**
 * Write a description of class Ship here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public abstract class Ship implements ShipInter
{
    private String name;
    private int year;
    private String imo;
    
    public Ship()
    {
        
    }
    
    public Ship(String name, int year, String imo)
    {
        setName(name);
        setYear(year);
        setIMO(imo);
    }
    
    public String getName()
    {
        return name;
    }
    public int getYear()
    {
        return year;
    }
    public String getIMO()
    {
        return imo;
    }
    
    public void setName(String name)
    {
        this.name=name;
    }
    public void setYear(int year)
    {
        this.year=year;
    }
    public void setIMO(String imo)
    {
        this.imo=imo;
    }
    
    @Override
    public String toString()
    {
        String str = String.format("%-15s%-20d%-10s", getName(), getYear(), getIMO());
        return str;
    }
}
