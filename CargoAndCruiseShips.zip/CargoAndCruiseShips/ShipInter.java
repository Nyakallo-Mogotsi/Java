
/**
 * Write a description of interface ShipInter here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public interface ShipInter
{
    
}
