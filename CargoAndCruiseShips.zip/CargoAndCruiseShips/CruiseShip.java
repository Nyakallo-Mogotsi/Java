
/**
 * Write a description of class CruiseShip here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class CruiseShip extends Ship
{
    private int numPassengers;
    private int passengersAboard;
    
    public CruiseShip()
    {
        
    }
    
    public CruiseShip(String name, int year, String imo, int numPassengers , int passengersAboard)
    {
        super(name,year,imo);
        setNumPassengers(numPassengers);
        setPassengersAboard(passengersAboard);
    }
    public void setNumPassengers(int numPassengers)
    {
        this.numPassengers=numPassengers;
    }
    public void setPassengersAboard(int passengersAboard)
    {
        this.passengersAboard=passengersAboard;
    }
    public int getNumPass()
    {
        return numPassengers;
    }
    public int getPassA()
    {
        return passengersAboard;
    }
    public void getAvailableSpace()
    {
        int space;
        
        space=getNumPass()-getPassA();
        
        for (int k=0 ; k<4 ; k++)
        {
            System.out.print(super.getName()+ " : " +space + " passengers");
        }
        
    }
    @Override
    public String toString()
    {
        String str=String.format("%s%-10d%-10d", super.toString(),getNumPass(),getPassA());
        
        return str;
    }
}
