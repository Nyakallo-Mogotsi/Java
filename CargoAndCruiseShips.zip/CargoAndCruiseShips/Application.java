import java.util.Scanner;
import java.io.FileReader;
import javax.swing.JOptionPane;
/**
 * Write a description of class Application here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Application
{
    int [] arrShip = new int[25];
    int count=0;
    int counter =5;
    public void readFromFile()
    {
        try
        {
            Scanner input = new Scanner(new FileReader("ships.txt"));
            while(input.hasNextLine())
            {
                String line = input.nextLine();
                String [] data = line.split(",");
                String name;
                String imo;
                int year;
                double cargoCap;
                double load;
                int numPassengers;
                int passengersAboard;
                
                if ((Character.toUpperCase(data[3].charAt(5))>=5))
                {
                    name = data[1];
                    year = Integer.parseInt(data[2]);
                    imo = data[3];
                    cargoCap = Double.parseDouble(data[5]);
                    load = Double.parseDouble(data[6]);
                    
                    arrShip[count]=new CargoShip(name, year,  imo,  cargoCap, load);
                }
                else
                {
                    name = data[1];
                    year = Integer.parseInt(data[2]);
                    imo =(data[3]);
                    numPassengers = Integer.parseInt(data[5]);
                    passengersAboard = Integer.parseInt(data[6]);
                    
                    arrShip[count]=new CruiseShip( name,  year,  imo,  numPassengers ,  passengersAboard);              
                }
                count++;
                counter++;
            }
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, "Error reading from file");
        }
    }
    
    
}

