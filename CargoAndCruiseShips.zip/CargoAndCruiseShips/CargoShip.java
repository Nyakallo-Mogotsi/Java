import java.util.Scanner;

/**
 * Write a description of class CargoShip here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class CargoShip extends Ship
{
    private double cargoCap;
    private double load;
    public CargoShip()
    {
        
    }
    public CargoShip(String name, int year, String imo, double cargoCap, double load)
    {
        super(name,year,imo);
        setCargoCap(cargoCap);
        setLoad(load);
        
    }
    public double getCargoCap()
    {
        return cargoCap;
    }
    public double getLoad()
    {
        return load;
    }
    public void setCargoCap(double cargoCap)
    {
        this.cargoCap=cargoCap;
    }
    public void setLoad(double load)
    {
        this.load=load;
    }
    public void getAvailableSpace()
    {
        double space;
        
        space=getCargoCap()-getLoad();
        
        for (int k=0 ; k<4 ; k++)
        {
            System.out.format(super.getName()+ " : %.2f" +space + " gt");
        }
        
    }
    public boolean requireCheck(int year)
    {
        double cap = (75/100)*cargoCap;
        boolean check;
        int currentYear;
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter current year: " );
        currentYear=sc.nextInt();
        int tempYear = currentYear-year;
        
        if ((tempYear>=20) && (load > cap))
        {
            check=true;
        }
        else
        {
            check=false;
        }
        return check;
    }
    // //*public void check(String[] arrShip)
    // {
        // if (requireCheck() = "true")
        // {
            // for(int k=0;k<25;k++)
            // {
                // System.out.print("Cargo Ships to be checked: /n"+ arrShip[k].getName());
            // }
        // }
    // }
    public String toString()
    {
        String str=String.format("%s%-20d%-20d", super.toString(),getCargoCap(), getLoad());

        return str;
    }
}



