

/**
 * Write a description of class Test here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Test
{
    public static void main(String[] args) {
        // Create a MyLinkedList and add elements
        MyLinkedList<String> myList = new MyLinkedList<>();
        myList.append("peep");
        myList.append("car");
        myList.append("rat");
        myList.append("otto");

        // Check if elements in the list are palindromes
        boolean[] results = new boolean[myList.size()];
        Node<String> thisNode = myList.head;
        int count = 0;
        while (thisNode != null) {
            results[count] = thisNode.isPalindrome();
            thisNode = thisNode.next;
            count++;
        }

        // Print the results
        System.out.print("[");
        for (int i = 0; i < results.length; i++) {
            System.out.print(results[i]);
            if (i < results.length - 1) {
                System.out.print(",");
            }
        }
        System.out.println("]");
    }
}
