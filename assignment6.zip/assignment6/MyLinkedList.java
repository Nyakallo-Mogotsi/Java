import java.util.ArrayList;
/**
 * Method is called reverse()
 * we are going to reverse the order of a linked list
 * this is going to be useful to people who would like to reverse a list from 
 * ascending to descending order or vise versa.
 *
 * @author (Nyakallo Mogotsi)
 * @version (a version number or a date)
 */


public class MyLinkedList<E>
{
    private Node<E> head, tail;

    public void append(E item)
    {
    
        Node<E> newNode = new Node<>(item); // Create a new for element e
    
        if (head == null) {
          head = tail = newNode; // The new node is the only node in list
        }
        else {
          tail.next = newNode; // Link the new with the last node
          tail = newNode; // tail now points to the last node
        }
    }
    
    public void reverse()
    {
        if (head == null || head.next == null)
        {
            return;// an empty list , means theres no need to exexute reverse()
        }
        Node<E> prevPtr = null;
        Node<E> currrentPtr = head;
        Node<E> nextPtr;

        while (currrentPtr != null)
        {
            nextPtr = currrentPtr.next;
            currrentPtr.next = prevPtr;
            prevPtr = currrentPtr;
            currrentPtr = nextPtr;
        }

        head = prevPtr;
    }
    
    public String toString()
    {
        String str = "{";
    
        Node<E> ptr = head;
        for (ptr= head;ptr!=null; ptr=ptr.next) 
        {
             str = str +  ptr.element.toString();     
             if (ptr.next != null)
                 str = str + ";"; 
        }
        str += "}"; 
        return str;
    }
  
    private static class Node<E>
    {
        E element;
        Node<E> next;
        
        public Node(E element)
        {
            this.element = element;
            next = null;
        }
    }

}



