import java.util.*;

/**
 * Write a description of class Test here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Test
{
    public static void main(String[] args)
    {
        MyLinkedList<Integer> linkedList = new MyLinkedList<>();

        linkedList.append(16);
        linkedList.append(90);
        linkedList.append(2);
        linkedList.append(44);
        linkedList.append(8); 
        
        System.out.println("List:");
        System.out.println(linkedList);

        linkedList.reverse();
        System.out.println("Reversed List:");
        System.out.println(linkedList);
    }
    
    
}
