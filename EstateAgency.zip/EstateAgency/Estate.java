
/**
 * Write a description of class EstateAgency here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public abstract class Estate implements Properties
{
    private String code;
    private String agent;
    
    public Estate ()
    {
        
    }
    public Estate(String code, String agent)
    {
        setCode(code);
        setAgent(agent);
    }
    public String getcode()
    {
        return code;
    }
    public void setCode(String code)
    {
        this.code=code;
    }
    public String getAgent()
    {
        return agent;
    }
    public void setAgent(String agent)
    {
        this.agent=agent;
    }
    public String sellorRent(String code)
    {
        int 
        
        if (code.in)
        {
            
        }
    }
}
