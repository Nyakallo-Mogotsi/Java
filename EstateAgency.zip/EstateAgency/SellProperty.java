
/**
 * Write a description of class SellProperty here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class SellProperty extends Estate
{
    private double sellPrice;
    
    public SellProperty()
    {
        
    }
    public SellProperty(int code, String agent, double sellPrice)
    {
        super(code,agent);
        setSellPrice(sellPrice);
    }
    public double getSellPrice()
    {
        return sellPrice;
    }
    public void setSellPrice(double sellPrice)
    {
        this.sellPrice=sellPrice;
    }
}
