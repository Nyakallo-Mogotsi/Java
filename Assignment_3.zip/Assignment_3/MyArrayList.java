import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.HashSet;

public class MyArrayList
{
    private List<Integer> row1 = new ArrayList<>();//create 4 parallel arrayLists
    private List<Integer> row2 = new ArrayList<>();
    private List<Integer> row3 = new ArrayList<>();
    private List<Integer> row4 = new ArrayList<>();
    
    public MyArrayList ()
    {
        this.row1= new ArrayList<>();
        this.row2= new ArrayList<>();
        this.row3= new ArrayList<>();
        this.row4= new ArrayList<>();
    }
    public boolean isAllGuessed()
    {
        List<Boolean> guessedNum = new ArrayList<>();//arraylist for the guessed numbers(whether they were guessed or not yet)
        guessedNum.add(false);//initialize all elements in the array as guessed 
        
        
        for (boolean isGuessedRight : guessedNum)
        {
            if (!isGuessedRight)
            {
                return false;//for loop that iterates through each element in the guessNum list , will check if all values are true
            }
            
        }
        return true;
    }
    
    public boolean isFull()
    {
        if (row1.size() >= 3 || row2.size() >= 3 || row3.size() >= 3 || row4.size() >= 3)
        {
            return true;// if all rows are full return true
        }
        else
        {
            return false;
        }
        
    }
    public static void main(String[] args)
    {
        List<Integer> row1 = new ArrayList<>();
        List<Integer> row2 = new ArrayList<>();
        List<Integer> row3 = new ArrayList<>();
        List<Integer> row4 = new ArrayList<>();
        Random random = new Random();

        int lowerBound1 = 1;//set bounds for row 1 random values
        int upperBound1 = 4;
        int count1 = upperBound1 - lowerBound1 + 1;//set count for the unrepeated numbers

        HashSet<Integer> hashset1 = new HashSet<>();//use a hashset because it doesnt allow duplicate values
        while (hashset1.size() < count1)
        {
            int random1 = random.nextInt(upperBound1 - lowerBound1 + 1) + lowerBound1;

            if (!hashset1.contains(random1))
            {
                hashset1.add(random1);
                row1.add(random1);
            }
        }

        int lowerBound2 = 5;//set bounds for row 2 random values
        int upperBound2 = 8;
        int count2 = upperBound2 - lowerBound2 + 1;

        HashSet<Integer> hashset2 = new HashSet<>();
        //This loop ensures that the number of unique random integers is generated.
        while (hashset2.size() < count2)
        {
            int random2 = random.nextInt(upperBound2 - lowerBound2 + 1) + lowerBound2;
            //create random integers between the bounds
            if (!hashset2.contains(random2))
            {
                hashset2.add(random2);
                row2.add(random2);
            }
            //if statement checks whether the generated random integer is already present in hashset2 ,ensuring non repeation.
        }

        int num1 = row1.get(0);//scramble values amongst row 3 and row 4
        int num2 = row1.get(3);
        int num3 = row1.get(1);
        int num4 = row1.get(2);

        row4.add(num1);
        row3.add(num2);
        row4.add(0, num3);
        row3.add(0, num4);

        int num5 = row2.get(0);
        int num6 = row2.get(2);
        int num7 = row2.get(1);
        int num8 = row2.get(3);

        row3.add(1, num5);
        row3.add(3, num6);
        row4.add(2, num7);
        row4.add(1, num8);
    


        System.out.print("[\t"+row1.get(0)+",\t,"+row1.get(1)+",\t,"+row1.get(2)+",\t,"+row1.get(3)+"]\n");
        System.out.print("[\t"+row2.get(0)+",\t,"+row2.get(1)+",\t,"+row2.get(2)+",\t,"+row2.get(3)+"]\n");
        System.out.print("[\t"+row3.get(0)+",\t,"+row3.get(1)+",\t,"+row3.get(2)+",\t,"+row3.get(3)+"]\n");
        System.out.print("[\t"+row4.get(0)+",\t,"+row4.get(1)+",\t,"+row4.get(2)+",\t,"+row4.get(3)+"]\n");
        //output
        
    }
}
