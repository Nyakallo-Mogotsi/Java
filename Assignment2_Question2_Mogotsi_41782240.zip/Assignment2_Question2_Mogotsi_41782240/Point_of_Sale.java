import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JTextField;



/**
 * Write a description of class Point_of_Sale here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Point_of_Sale implements ActionListener
{
    public Point_of_Sale()
    {
        JFrame frame = new JFrame();
        JTextField textfield;
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setBounds(0,0,700,700);
        Container container = frame.getContentPane();
        container.setLayout(null);
        JButton btn1,btn2,btn3,btn4,btn5,btn6,btn7,btn8;
        String[] medi = {"Panado" , "Ibuprofen" , "Allergex" , "Alcophyllex" , "Illiadin" , "Amoxicillin" , "Adderall"};
        int[] prices = {36,44,29,30,50,67,86};
        int[] stock = {20,25,12,29,70,16,8};
        
        btn1 = new JButton("Add Stock");
        btn1.setBounds(10, 40, 200, 40);
        container.add(btn1);
        btn1.addActionListener(this);
        
        btn2 = new JButton("Purchase");
        btn2.setBounds(240, 40, 200, 40);
        container.add(btn2);
        btn2.addActionListener(this);
        
        btn3 = new JButton("Total Sale");
        btn3.setBounds(470, 40, 200, 40);
        container.add(btn3);
        btn3.addActionListener(this);
        
        btn4 = new JButton("Add Items");
        btn4.setBounds(10, 140, 200, 40);
        container.add(btn4);
        btn4.addActionListener(this);
        
        btn5 = new JButton("Delete Items");
        btn5.setBounds(240, 140, 200, 40);
        container.add(btn5);
        btn5.addActionListener(this);
        
        btn6 = new JButton("Show Items");
        btn6.setBounds(470 ,140, 200, 40);
        container.add(btn6);
        btn6.addActionListener(this);
        
        btn7 = new JButton("Sold Items");
        btn7.setBounds(10, 240, 200, 40);
        container.add(btn7);
        btn7.addActionListener(this);
        
        btn8= new JButton("Exit");
        btn8.setBounds(470, 240, 200, 40);
        container.add(btn8);
        btn8.addActionListener(this);
        
        frame.setVisible(true);
        
        
    }
    
    public static void main(String args[])
    {
        Point_of_Sale btnevents = new Point_of_Sale();
    }
  
    public void actionPerformed(ActionEvent argO)
    {
        
        //throw new UnsupportedOperationExpectation("Not supported yet.");
    }
}

