
/**
 * Write a description of class Assignment here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */

import java.util.Scanner;
public class Assignment
{
     public static void main(String [] args) {
        String[] arrAnswer ={"instructions","specific","execution","state","behaviour","fields","methods","encapsulation","class","superclass","subclass","extends","interface","package"};
        Scanner sc= new Scanner(System.in);
        String answer;
        int count=0;
        
        
        System.out.println("A program is a set of [1] written in a specific computer programming language (i.e. JAVA) to solve a [2] problem. These computer instructions are written by a programmer using a programming language for [3] by a computer.Real-world objects contain [4] and [5]. A software object's state is stored in [6]. A software object's behavior is exposed through [7]. Hiding internal data from the outside world, and accessing it only through publicly exposed methods is known as data [8]. A blueprint for a software object is called a [9]. Common behavior can be defined in a [10] and inherited into a [11] using [12] keyword. A collection of methods with no implementation is called an [18]. A namespace that organizes classes and interfaces by functionality is called a [14]./n");
        
        for(int k=0;k<13;k++){
       System.out.println("Enter an Answer for "+ (k+1));
       answer=sc.next();
    
       if(answer.equals(arrAnswer[k])){
            count+=1;
        }
       
       
    }
    System.out.println(count+" answers are correct");
    }
}

}