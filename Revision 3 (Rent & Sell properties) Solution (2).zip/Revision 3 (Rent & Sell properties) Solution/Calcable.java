
/**
 * Write a description of interface Calcable here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public interface Calcable
{
    double calcCommission(double perc);
    double calcAmount();
    String toString();
}
