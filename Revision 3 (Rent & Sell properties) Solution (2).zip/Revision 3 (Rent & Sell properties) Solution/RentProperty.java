/**
 * Write a description of class RentProperty here.
 *
 * @author ()
 * @version ()
 */
public class RentProperty extends Property
{
    private double rent;
    private int duration;
    
    public RentProperty(String code, String agentName, double rent, int duration)
    {
        super(code, agentName);
        setRent(rent);
        setDuration(duration);
    }
    
    public void setRent(double rent)
    {
        this.rent = rent;
    }
    
    public void setDuration(int duration)
    {
        this.duration = duration;
    }
    
    public double getRent()
    {
        return rent;
    }
    
    public int getDuration()
    {
        return duration;
    }
    
    public double calcCommission(double perc)
    {
        if (super.getCode().charAt(1) > '2' )
          perc = perc + 2.5;
        double comm = rent * perc/100;
        return comm;
    }
    
    public double calcAmount()
    {
        double amount = rent * duration;
        return amount;
    }
    @Override
    public String toString()
    {
        String str = String.format("%s%2d@R %8.2f" , super.toString(),duration,rent);
        return str;
    }
   
}
