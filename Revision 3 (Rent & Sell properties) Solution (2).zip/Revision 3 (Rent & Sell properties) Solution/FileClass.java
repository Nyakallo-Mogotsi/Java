
/**
 * Write a description of class FileClass here.
 *
 * @author ()
 * @version ()
 */

import java.util.Scanner;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.io.EOFException;
import javax.swing.JOptionPane;
import java.text.NumberFormat;

public class FileClass
{
    private Property [] arrProperties = new Property[25];
    private int count = 0;
    
    public void readFromFile(String fileName)
   {
    try
        {
            Scanner sc = new Scanner(new FileReader(fileName));

            while (sc.hasNext())
            {
              String line = sc.nextLine();
              String [] info = line.split("#");

              String code = info[0];
              String name = info[1];
              
              if (code.charAt(0) == '1' )
              {
                  double price = Double.parseDouble(info[2]);
                  arrProperties[count] = new SellProperty(code, name, price);
              }
              else
              {
                  double rent = Double.parseDouble(info[2]);
                  int duration = Integer.parseInt(info[3]);
                  arrProperties[count] = new RentProperty(code, name, rent, duration);
              }
              count++;
            }
                
            sc.close();
        }
        catch (Exception e)
        {
            JOptionPane.showMessageDialog(null, "Error using the file");
        }
    }
    
    public int getCount()
    {
        return count;
    }
        
    public Property [] getArray()
    {
        return arrProperties;
    }
    
    public void serializeObjectsToFile() 
    {
        
    try
    {
        FileOutputStream file = new FileOutputStream("sellprop.ser");
        ObjectOutputStream out = new ObjectOutputStream(file);
        for(int k = 0; k < count;k++)
        {
            if (arrProperties[k] instanceof SellProperty)
                out.writeObject(arrProperties[k]);
        }
            
        out.close();
        file.close();
    }
    catch(IOException ex)
    {
        System.out.println(ex);
    }
            

    }
    
     public void readObjects() 
   {
      double total = 0;
      int count = 0;
      //
      System.out.println("\nList of properties for sale");
      try
      {
        ObjectInputStream in = new ObjectInputStream(new FileInputStream("sellprop.ser"));
        while (true)
        {
            SellProperty prop = (SellProperty)in  .readObject();
            total = total + prop.calcAmount();
            count++;
            System.out.printf("%-12s %15s\n", prop.getAgent(), NumberFormat.getCurrencyInstance().format(prop.calcAmount()));
        }  
      }
      catch (EOFException endOfFileException)
      {
        System.out.println("");
        double ave = total /count; 
        System.out.println("Average selling price: " + NumberFormat.getCurrencyInstance().format(ave));
        System.exit(0);
      }
      catch (ClassNotFoundException classNotFoundException)
      {
        System.err.println("Invalid object type. Terminating.");
      }
      catch (IOException ioException)
      {
        System.err.println("Error reading from file. Terminating.");
      }
   }
    
    
}

