
/**
 * Abstract class Property - write a description of the class here
 *
 * @author ()
 * @version ()
 */
import java.io.Serializable;
public abstract class Property implements Calcable, Serializable, Comparable<Property>
{
    private String code;
    private String agentName;
    
    public Property()
    {
        this("", "");
    }
    
    public Property(String code, String agentName)
    {
        setCode(code);   
        setAgent(agentName);   
    }
    
    public void setCode(String code)
    {
        this.code = code;
    }
    
    public void setAgent(String agentName)
    {
        this.agentName = agentName;
    }
    
    public String getCode()
    {
        return code;
    }
    
    public String getAgent()
    {
        return agentName;
    }
    
    @Override
    public int compareTo(Property property)
    {
        String thisObj =  this.getCode().charAt(0) + this.getAgent();
        String otherObj = property.getCode().charAt(0) + property.getAgent();
        return thisObj.compareTo(otherObj);
    }
    
    public abstract double calcCommission(double perc);
    public abstract double calcAmount();
    
    @Override
    public String toString()
    {
        String str = String.format("%-15s%-15s", code, agentName);
        return str;
    }    
    
}
