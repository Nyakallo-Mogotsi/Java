
/**
 * Write a description of class SellProperty here.
 *
 * @author ()
 * @version ()
 */
public class SellProperty extends Property
{
    private double sellPrice;
    
    public SellProperty(String code, String agentName, double sellPrice)
    {
        super(code, agentName);
        setPrice(sellPrice);
    }
    
    public void setPrice(double sellPrice)
    {
        this.sellPrice = sellPrice;
    }
    public double getPrice()
    {
        return sellPrice;
    }
    
    public double calcCommission(double perc)
    {
        double comm = calcAmount() * perc/100;
        return comm;
    }
    
    public double calcAmount()
    {
        double tax = 0;
        if (sellPrice >= 500000 && sellPrice <= 1000000)
           tax = 10;
        if (sellPrice > 1000000)
           tax = 15;
        double amount = sellPrice + (sellPrice * tax/100);
        return amount;
    }
    @Override
    public String toString()
    {
        String str = String.format("%s R %10.2f" , super.toString(),sellPrice);
        return str;
    }
   
}
