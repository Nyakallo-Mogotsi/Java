
/**
 * Write a description of class testPropertties here.
 *
 * @author ()
 * @version ()
 */
import java.util.Arrays;
public class testProperties
{
    public static void main(String [] args) throws Exception
    {
        Calcable [] arrProperties = new Calcable[25];
        
        FileClass file = new FileClass();  // or call static readData method or write code to read data here
       
        file.readFromFile("propertydata.txt" );
        arrProperties = file.getArray();
        int count = file.getCount();z
        
        display(arrProperties, count);
        arrProperties = Arrays.copyOf(arrProperties, count);
        Arrays.sort(arrProperties,0,count);
        
        
        System.out.print("\n\n=====\n====Sorted\n======\n=====");
        
        
        display(arrProperties, count);
        file.serializeObjectsToFile();
        file.readObjects();
        
        
    }
    
    public static void display(Calcable [] arrProperties, int count)
    {
        System.out.println("\nList of properties");
        System.out.printf("%-15s%-18s%-19s%-16s%-14s\n","Code", "Agent","Price/Rent", "Amount", "Comm" ); 
        
        for(int k = 0; k < count; k++)
        {
            Calcable prop = arrProperties[k];
            System.out.printf("%s   R %10.2f    R %8.2f\n",prop.toString(), prop.calcAmount(), prop.calcCommission(5)); 
        }
    }
    
    
}
