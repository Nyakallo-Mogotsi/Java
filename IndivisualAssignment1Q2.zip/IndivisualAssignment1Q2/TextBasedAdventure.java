import java.util.Scanner;
/**
 * Write a description of class TextBasedAdventure here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class TextBasedAdventure
{

    Scanner sc = new Scanner(System.in);
    Scanner scText = new Scanner(System.in);
    int playerHP;
    String Name;
    String Weapon;
    int choice;
    int thugHP;
    int Gold;

    public void playerSetUp()
    {
        playerHP = 10;
    thugHP = 15;
        Weapon = "pistol";

    System.out.println("Your HP: " + playerHP);
    System.out.println("Your Weapon: " + Weapon);

    System.out.println("Please enter your name:");

    Name = sc.nextLine();

    System.out.println("Hello " + Name + ", let's start to play POLICE ACADEMY");

    }
    
    public void policeStation()
    {
        System.out.println("\n------------------------------------------------------------------\n");
    System.out.println("You are at the gate of the police station. You want to become a police officer.");
    System.out.println("A policeman is standing in front of you.");
    System.out.println("");
    System.out.println("What do you do?");
    System.out.println("");
    System.out.println("1: Chat with the policeman");
    System.out.println("2: Attack the policeman");
    System.out.println("3: Exit");
        System.out.println("\n------------------------------------------------------------------\n");

    choice = sc.nextInt();

        if (choice == 1) 
        {
            if (Gold == 1)
            {
            ending();
            }
            else
            {
        System.out.println("policeman: Hello there, " + Name+ "\nWe cannot let you become an officer. You lack experince.");
        scText.nextLine();
        policeStation();
            }

        }
        else if
            (choice == 2)
        {
            playerHP = playerHP - 1;
            System.out.println("policeman: Don't test me.\nYou miss.\nThe policeman shoots you first.\n(You receive 1 hit!)\n");
            System.out.println("Your HP: " + playerHP);
            scText.nextLine();
            policeStation();
    }
    else if
            (choice == 3)
    {
            crossRoad();
    } 
    else
    {
            policeStation();
    }
    }
    public void crossRoad()
    {
    System.out.println("\n------------------------------------------------------------------\n");
    System.out.println("You are at a crossroad. If you go North, you will go back to the police station.\n\n");
    System.out.println("1: Go south");
    System.out.println("2: Go east");
    System.out.println("3: Go north");
    System.out.println("4: Go west");
    System.out.println("\n------------------------------------------------------------------\n");

    choice = sc.nextInt();

    if (choice == 1)
    {
            south();
    } 
    else if (choice == 2) 
    {
            east();
    } else if (choice == 3)
    {
            policeStation();
    } else if (choice == 4)
    {
            west();
    } else
        {
            crossRoad();
    }
    }

    public void south() {
    System.out.println("\n------------------------------------------------------------------\n");
    System.out.println("You are at a clinic. The nurses patch you up.");
    System.out.println("Your HP is recovered.");
    playerHP = playerHP + 1;
    System.out.println("Your HP: " + playerHP);
    System.out.println("\n\n1: Go back to the crossroad");
    System.out.println("\n------------------------------------------------------------------\n");

    choice = sc.nextInt();

    if (choice == 1)
    {
            crossRoad();
    }
    else
        {
            south();
    }
    }

    public void east()
    {
        System.out.println("\n------------------------------------------------------------------\n");
        System.out.println("You walk to a gun store and you purchase a bigger gun , THE AK47!");
        Weapon = "AK47";
        System.out.println("Your Weapon: " + Weapon);
        System.out.println("\n\n1: Go back to the crossroad");
        System.out.println("\n------------------------------------------------------------------\n");
    
        choice = sc.nextInt();
    
        if (choice == 1)
        {
            crossRoad();
        }
        else
        {
            east();
        }
    }
    
    public void west()
    {
    System.out.println("\n------------------------------------------------------------------\n");
    System.out.println("You encounter a group of thugs!\n");
    System.out.println("1: Fight");
    System.out.println("2: Run");
    System.out.println("\n------------------------------------------------------------------\n");

    choice = sc.nextInt();

    if (choice == 1)
    {
            fight();
    } else if (choice == 2)
    {
            crossRoad();
    } else
    {
            west();
    }
    }

    public void fight() 
    {
    System.out.println("\n------------------------------------------------------------------\n");
    System.out.println("Your HP: " + playerHP);
    System.out.println("Thug HP: " + thugHP);
    System.out.println("\n1: Attack");
    System.out.println("2: Run");
    System.out.println("\n------------------------------------------------------------------\n");

    choice = sc.nextInt();

    if (choice == 1)
    {
            attack();
    } else if (choice == 2)
    {
            crossRoad();
    }
    else 
    {
            fight();
    }
    }

    public void attack() 
    {
    int playerHits = 0;

    if (Weapon.equals("Knife"))
    {
            playerHits = new java.util.Random().nextInt(4);
    } 
    else if (Weapon.equals("AK47"))
    {
            playerHits = new java.util.Random().nextInt(5);
    }

    System.out.println("You attacked the thugs and gave " + playerHits + " damage!");

    thugHP = thugHP - playerHits;

    System.out.println("thug HP: " + thugHP);

    if (thugHP < 1)
    {
            win();
    }
    else if (thugHP > 0)
    {
            int thugHits = 0;
        
            thugHits = new java.util.Random().nextInt(4);
            
            System.out.println("The thugs attacked you and gave " + thugHits + " damage!");
            
            playerHP = playerHP - thugHits;
            
            System.out.println("Player HP: " + playerHP);
            
            if (playerHP < 1) {
                dead();
            }
            else if (playerHP > 0)
            {
                fight();
            }
    }
    }

    public void dead() {
    System.out.println("\n------------------------------------------------------------------\n");
    System.out.println("YOU ARE DEAD!!!");
    System.out.println("\n\nGAME OVER:(");
    System.out.println("\n------------------------------------------------------------------\n");

    }

    public void win() {
    System.out.println("\n------------------------------------------------------------------\n");
    System.out.println("You killed all the thugs!");
    System.out.println("The thugs have gold in their pockets, you search their pockets and you take the gold!");
    System.out.println("You obtaind 5 gold pieces!\n\n");
    System.out.println("1: Go east");
    System.out.println("\n------------------------------------------------------------------\n");

    Gold = 5;

    choice = sc.nextInt();
    if (choice == 1) {
        crossRoad();
    } else {
        win();
    }

    }

    public void ending()
    {
    System.out.println("\n------------------------------------------------------------------\n");
    System.out.println("The police arrive at the crime scene...\nPolice officer: You got all the thugs!?? That's incredible!");
    System.out.println("Police officer: You have gained experience. Welcome to the police academy! Good luck , You'll need it");
    System.out.println("\n\n           END                    ");
    System.out.println("\n------------------------------------------------------------------\n");
    }
    
    public static void main(String[] args)
    {
    TextBasedAdventure game;
    game = new TextBasedAdventure();

    game.playerSetUp();
    game.policeStation();
    } 
}
