
/**
 * Write a description of class Ebook here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class EBook extends Book
{
    private int size;
    public EBook()
    {
        
    }
    
    public EBook(String title, String author, String isbn, int Size)
    {
        super(title, author, isbn);
        setSize(size);
    }
    
    public void getSizeDetails(String title)
    {
        System.out.print("EBook: " + title +" ,File size: "+ Integer.toString(size)+" KB");
    }
    
    public int getSize()
    {
        return size;
    }
    
    public void setSize(int size)
    {
        
    }
    
    public void output(String title)
    {
        super.output();
        
        System.out.print("Size Information: \n");
        getSizeDetails(title);
    }
}