
/**
 * Write a description of class PrintBook here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class PrintBook extends Book
{
    private int pages;
    private double weight;
    public PrintBook()
    {
        
    }
    
    public PrintBook(String title,String author , String isbn , int pages , double weight )
    {
        super(title,author , isbn);
        this.pages=pages;
        this.weight=weight;
    }
    
    public void getSizeDetails(String title)
    {
        System.out.print("PrintBook: " + title +" ,"+ Integer.toString(pages)+" pages ,Weight: "+ Double.toString(weight)+" KG");
    }

    public int getPages()
    {
        return pages;
    }
    
    public double getWeight()
    {
        return weight;
    }
    
    public void output(String title)
    {
        super.output();
        
        System.out.print("Size Information: \n");
        getSizeDetails(title);
    }
}
