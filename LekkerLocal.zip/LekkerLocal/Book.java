
/**
 * Write a description of class Book here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public abstract class Book implements BookInter
{
    private String title;
    private String author;
    private String isbn;
   
    public Book()
    {
        
    }
    
    public Book(String title,String author , String isbn )
    {
        setTitle(title);
        setISBN(isbn);
        setAuthor(author);
    }
    
    public String getTitle()
    {
        return title;
    }
    public String getAuthor()
    {
        return author;
    }
    public String getISBN()
    {
        return isbn;
    }
    
    public void setTitle(String title)
    {
        
    }
    public void setAuthor(String author)
    {
        
    }
    public void setISBN(String isbn)
    {
        
    }
    
    public void output()
    {
        System.out.print("List of Books: \n" + getTitle() + " by " + getAuthor() + ", ISBN: " + getISBN());
    }
}