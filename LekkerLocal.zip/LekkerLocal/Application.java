import java.util.Scanner;
import java.util.ArrayList;
import java.io.File;
import java.io.PrintWriter;
import java.io.FileReader;
import javax.swing.JOptionPane;
import java.util.*;
/**
 * Write a description of class Application here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Application
{
    ArrayList<BookInter> arrBooks = new ArrayList<BookInter>();
    int count = 0;


    public void readFromFile()
    {
        try
        {
            Scanner input = new Scanner(new FileReader("books.txt"));
            while(input.hasNextLine())
            {
                String line = input.nextLine();
                String [] data = line.split("#");
                String title;
                String author;
                String isbn;
                int pages;
                double weight;
                int size; 
                
                
                switch(data[2].charAt(0))
                {
                    case '0':
                        title = data[0];
                        author = data[1];
                        isbn = data[2];
                        pages = Integer.parseInt(data[3]);
                        weight = Integer.parseInt(data[4]);
                        
                        arrBooks.add(new PrintBook(title , author , isbn , pages , weight));
                        //arrProperties[counter] = new ResProperty(.....);
                        break;
                        
                    case '1':
                        title = data[0];
                        author = data[1];
                        isbn = data[2];
                        size = Integer.parseInt(data[3]);
                        arrBooks.add(new EBook(title , author , isbn, size));
                        break;
                    }
                    count++;
                }
                            
                        
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, "Error reading from file");
        }
    }
    //*public void sort()
    {
        try
        {
        Scanner sc = new Scanner(new FileReader("books.txt"));
        String line = sc.nextLine();
        String [] data = line.split("#");
        switch(data[2].charAt(0))
                {
                    case '0':
                            
                        break;
                        
                    case '1':
                            sort(arrBooks);              
                        break;
                }
        }
        catch(Exception e)
        {
            
        }
    }
    //*
    public int getCount(){
        return count;
    }
    
    public ArrayList<BookInter> getArray(){
        return arrBooks;
    }
}