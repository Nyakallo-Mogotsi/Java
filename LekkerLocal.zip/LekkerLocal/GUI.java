import javafx.scene.control.TextField;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.geometry.*;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import javafx.scene.layout.StackPane;
import java.util.Random;
import javafx.scene.control.TextArea;
import javafx.scene.control.Alert;
/**
 * Write a description of JavaFX class GUI here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class GUI extends Application 
{
    TextField tf = new TextField();
    
    Button validate = new Button("Validate");
    public static void main(String[] args) {
        launch(args);
        
    }
    
    @Override
    public void start(Stage primaryStage) throws Exception 
    {
        primaryStage.setTitle("Validate ISBN Numbers");
        
        StackPane layout = new StackPane();
        Scene scene = new Scene(layout, 500 , 300);
        Label l1 = new Label("ISBN specifications: 10 digits, last can be X");
        Label l2 = new Label("Enter an ISBN: ");
        Label l3 = new Label("...");
        Label l4 = new Label("...");
        
        layout.getChildren().addAll(l1,l2,tf,validate,l3,l4);
        
        StackPane.setAlignment(l1, Pos.TOP_LEFT);
        StackPane.setMargin(l1, new Insets(10));
        
        StackPane.setAlignment(l2, Pos.TOP_LEFT);
        StackPane.setMargin(l2, new Insets(50,50,50,10));
        
        StackPane.setAlignment(tf, Pos.TOP_LEFT);
        StackPane.setMargin(tf, new Insets(80,90,30,10));
        tf.setPrefWidth(10);
        
        StackPane.setAlignment(validate, Pos.TOP_LEFT);
        StackPane.setMargin(validate, new Insets(130,90,30,10));
        
        StackPane.setAlignment(l3, Pos.TOP_LEFT);
        StackPane.setMargin(l3, new Insets(180,90,30,10));

        StackPane.setAlignment(l4, Pos.TOP_LEFT);
        StackPane.setMargin(l4, new Insets(210,90,30,10));

        primaryStage.setScene(scene);
        primaryStage.show();
        
        validate.setOnAction(event -> 
        {
            validate();
        });
    }
    public String getText()
    {
        String num = tf.getText();
        
        return num;
    }
    public void validate()
    {
        if (getText().length()<10 || getText().length()>10)
        {
            Label l3 = new Label("Invalid ISBN");
            Label l4 = new Label("Check Number of digits");
        }
        else if (getText().matches("[0-9]+"))
        {
            Label l3 = new Label("Valid ISBN");
            
        }
        else if (getText().charAt(9)=='X')
        {
            Label l3 = new Label("Valid ISBN");
        }
        else
        {
            Label l3 = new Label("Invalid ISBN");
            Label l4 = new Label("All characters not digits, check number of digits");
        }
    }
}
